<footer>
  <div class="container p-y3 grid">
    <div class="footer-body f-middle">
      <h3 class="f-sm-1 f-w-heavy f-ls-2">Contact</h3>
      <div class="contact-info m-y3">
        <p class="f-sm-ex m-y1"><span class="f-sm-ex f-w-heavy row-head">PHONE NO: </span>018-250 2634</p>
        <p class="f-sm-ex m-y1"><span class="f-sm-ex f-w-heavy row-head">EMAIL: </span>user2140@hotmail.com</p>
      </div>
      <div class="social flex">
        <a href="https://www.facebook.com/hydraulicjack2140"><i class="m-x-sm f-sm-1 fab fa-facebook"></i></a>
        <a href="https://www.instagram.com/hydraulicjack_official/"><i class="m-x-sm f-sm-1 fab fa-instagram"></i></a>
        <a href="https://www.youtube.com/channel/UCK2wEIhrD4FLNnoxq_8Ydqg"><i class="m-x-sm f-sm-1 fab fa-youtube"></i></a>
        <a href="https://www.artstation.com/jackkang"><i class="m-x-sm f-sm-1 fab fa-artstation"></i></a>
      </div>
    </div>
    <div class="copyright f-middle">
      <h1 class="f-sm-1">HYDRAULIC JACK</h1>
      <p class="f-sm-ex">Copyright &copy; 2020</p>
    </div>
  </div>
</footer>
